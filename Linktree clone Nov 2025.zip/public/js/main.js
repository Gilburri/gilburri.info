// Gilburri Linktree - Interactive Enhancements
(function() {
    'use strict';
    
    // DOM Elements
    const linkCards = document.querySelectorAll('.link-card');
    const profileImage = document.querySelector('.profile-image');
    
    // Initialize when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        initializeAnimations();
        initializeClickTracking();
        initializeHoverEffects();
        initializeKeyboardNavigation();
        initializeImageLoading();
    });
    
    // Initialize scroll animations
    function initializeAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.animationDelay = Math.random() * 0.3 + 's';
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);
        
        // Observe all link cards for scroll animations
        linkCards.forEach((card, index) => {
            card.style.animationDelay = (index * 0.1) + 's';
            observer.observe(card);
        });
    }
    
    // Initialize click tracking
    function initializeClickTracking() {
        linkCards.forEach(card => {
            card.addEventListener('click', function(e) {
                const linkTitle = this.querySelector('.link-title')?.textContent || 'Unknown Link';
                const linkUrl = this.href || 'No URL';
                
                // Add click animation
                this.style.transform = 'scale(0.98)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 150);
                
                // Track analytics (placeholder for future implementation)
                console.log(`Link clicked: ${linkTitle} - ${linkUrl}`);
                
                // Visual feedback for external links
                if (this.target === '_blank') {
                    showExternalLinkIndicator(this);
                }
            });
        });
    }
    
    // Show external link indicator
    function showExternalLinkIndicator(card) {
        const indicator = document.createElement('div');
        indicator.className = 'external-link-indicator';
        indicator.innerHTML = '↗';
        indicator.style.cssText = `
            position: absolute;
            top: 8px;
            right: 8px;
            font-size: 12px;
            color: var(--primary-ochre);
            opacity: 0;
            transition: opacity 0.3s ease;
        `;
        
        card.style.position = 'relative';
        card.appendChild(indicator);
        
        // Fade in the indicator
        setTimeout(() => {
            indicator.style.opacity = '1';
        }, 100);
        
        // Fade out and remove
        setTimeout(() => {
            indicator.style.opacity = '0';
            setTimeout(() => {
                if (indicator.parentNode) {
                    indicator.parentNode.removeChild(indicator);
                }
            }, 300);
        }, 2000);
    }
    
    // Initialize enhanced hover effects
    function initializeHoverEffects() {
        linkCards.forEach(card => {
            // Add ripple effect on click
            card.addEventListener('click', function(e) {
                const rect = this.getBoundingClientRect();
                const ripple = document.createElement('span');
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                ripple.style.cssText = `
                    position: absolute;
                    width: 20px;
                    height: 20px;
                    background: rgba(210, 105, 30, 0.3);
                    border-radius: 50%;
                    transform: scale(0);
                    animation: ripple 0.6s linear;
                    left: ${x - 10}px;
                    top: ${y - 10}px;
                    pointer-events: none;
                    z-index: 2;
                `;
                
                this.style.position = 'relative';
                this.appendChild(ripple);
                
                setTimeout(() => {
                    if (ripple.parentNode) {
                        ripple.parentNode.removeChild(ripple);
                    }
                }, 600);
            });
            
            // Enhanced hover with magnetic effect
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-3px) scale(1.02)';
                this.style.boxShadow = '0 8px 35px rgba(139, 69, 19, 0.25)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = '';
                this.style.boxShadow = '';
            });
            
            // Parallax effect for thumbnails
            const thumbnail = card.querySelector('.link-thumbnail');
            if (thumbnail) {
                card.addEventListener('mousemove', function(e) {
                    const rect = this.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;
                    const centerX = rect.width / 2;
                    const centerY = rect.height / 2;
                    const rotateX = (y - centerY) / 10;
                    const rotateY = (centerX - x) / 10;
                    
                    thumbnail.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
                });
                
                card.addEventListener('mouseleave', function() {
                    thumbnail.style.transform = '';
                });
            }
        });
    }
    
    // Initialize keyboard navigation
    function initializeKeyboardNavigation() {
        linkCards.forEach((card, index) => {
            card.setAttribute('tabindex', '0');
            card.setAttribute('role', 'button');
            card.setAttribute('aria-label', `Visit ${card.querySelector('.link-title')?.textContent || 'link'}`);
            
            card.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.click();
                }
                
                // Arrow key navigation
                if (e.key === 'ArrowDown' && index < linkCards.length - 1) {
                    e.preventDefault();
                    linkCards[index + 1].focus();
                }
                
                if (e.key === 'ArrowUp' && index > 0) {
                    e.preventDefault();
                    linkCards[index - 1].focus();
                }
            });
        });
    }
    
    // Initialize image loading with fallbacks
    function initializeImageLoading() {
        const images = document.querySelectorAll('img');
        
        images.forEach(img => {
            img.addEventListener('load', function() {
                this.style.opacity = '1';
            });
            
            img.addEventListener('error', function() {
                // Create fallback for missing images
                const fallback = document.createElement('div');
                fallback.className = 'image-fallback';
                fallback.innerHTML = `
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                `;
                fallback.style.cssText = `
                    width: 48px;
                    height: 48px;
                    background: var(--light-gray);
                    border-radius: 12px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: var(--dark-gray);
                `;
                
                img.style.display = 'none';
                img.parentNode.appendChild(fallback);
            });
        });
        
        // Profile image enhancement
        if (profileImage) {
            profileImage.addEventListener('load', function() {
                this.style.filter = 'brightness(1.05) contrast(1.1)';
                setTimeout(() => {
                    this.style.filter = '';
                }, 500);
            });
        }
    }
    
    // Utility functions
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    function throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    }
    
    // Smooth scroll to top function (if needed)
    function scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }
    
    // Add ripple animation to CSS dynamically
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        .animate-in {
            animation: slideInUp 0.6s ease-out forwards;
        }
        
        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .link-card:focus {
            outline: 3px solid var(--primary-ochre);
            outline-offset: 2px;
        }
    `;
    document.head.appendChild(style);
    
    // Expose utility functions globally
    window.gilburriLinktree = {
        scrollToTop: scrollToTop,
        trackEvent: function(category, action, label) {
            // Placeholder for analytics tracking
            console.log('Analytics:', { category, action, label });
        }
    };
    
    // Performance monitoring
    if ('performance' in window) {
        window.addEventListener('load', function() {
            setTimeout(function() {
                const perfData = performance.getEntriesByType('navigation')[0];
                console.log('Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
            }, 0);
        });
    }
    
})();